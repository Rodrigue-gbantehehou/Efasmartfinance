<?php

namespace App\Controller\Dashboard;

use App\Entity\User;
use App\Entity\Tontine;
use App\Entity\Withdrawals;
use App\Service\ActivityLogger;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[IsGranted('ROLE_USER')]
#[Route('/dashboard')]
final class WithdrawalsController extends AbstractController
{
    public function __construct(
        private EntityManagerInterface $em,
        private ActivityLogger $activityLogger
    ) {}
    
    #[Route('/withdrawals', name: 'app_withdrawals_index', methods: ['GET'])]
    public function index(): Response
    {
        /** @var User $user */
        $user = $this->getUser();
        
        // Récupérer les demandes de retrait de l'utilisateur triées par date décroissante
        $withdrawals = $this->em->getRepository(Withdrawals::class)->findBy(
            ['utilisateur' => $user],
            ['requestedAt' => 'DESC']
        );

        return $this->render('dashboard/pages/withdrawals/index.html.twig', [
            'withdrawals' => $withdrawals,
        ]);
    }

    #[Route('/withdrawals/request/{id}', name: 'app_withdrawal_request', methods: ['GET'])]
    public function requestWithdrawal(Tontine $tontine): Response
    {
        // Vérifier si l'utilisateur est autorisé
        if ($tontine->getUtilisateur() !== $this->getUser()) {
            $this->addFlash('error', 'Accès non autorisé.');
            return $this->redirectToRoute('app_dashboard');
        }

        return $this->render('dashboard/pages/withdrawals/request.html.twig', [
            'tontine' => $tontine
        ]);
    }

    #[Route('/withdrawals/{id}', name: 'app_tontine_withdraw', methods: ['POST','GET'])]
    public function withdraw(Request $request, EntityManagerInterface $em,$id): Response
    {
        // Récupérer l'ID de la tontine depuis les paramètres de requête
        $tontineId = $id;

        if (!$tontineId) {
            $this->addFlash('error', 'Aucune tontine spécifiée pour le retrait.');
            return $this->redirectToRoute('app_dashboard');
        }

        // Récupérer la tontine
        $tontine = $em->getRepository(Tontine::class)->find($tontineId);
        if (!$tontine) {
            $this->addFlash('error', 'Tontine non trouvée.');
            return $this->redirectToRoute('app_dashboard');
        }

        // Vérifier si l'utilisateur est autorisé à effectuer un retrait
        /** @var User $user */
        $user = $this->getUser();
        if ($tontine->getUtilisateur()->getId() !== $user->getId()) {
            $this->addFlash('error', 'Vous n\'êtes pas autorisé à effectuer de retrait pour cette tontine.');
            return $this->redirectToRoute('app_dashboard');
        }

        // Récupérer les données du formulaire
        $amount = $tontine->getTotalPay();
        $method = 'momo pay';
        $reason = 'Retrait de la tontine';

        // Validation des données
        if (!$amount || !is_numeric($amount) || $amount <= 0) {
            $this->addFlash('error', 'Le montant du retrait est invalide.');
            return $this->redirectToRoute('app_tontines_show', ['id' => $tontineId]);
        }

        if (!$method) {
            $this->addFlash('error', 'Veuillez sélectionner une méthode de retrait.');
            return $this->redirectToRoute('app_tontines_show', ['id' => $tontineId]);
        }

        // Vérifier si le solde est suffisant
        if ($tontine->getTotalPay() < $amount) {
            $this->addFlash('error', 'Solde insuffisant pour effectuer ce retrait.');
            return $this->redirectToRoute('app_tontines_show', ['id' => $tontineId]);
        }

        
        

        try {
            // Vérifier s'il y a déjà une demande en cours
            $demande_en_cours = $em->getRepository(Withdrawals::class)->findOneBy([
                'tontine' => $tontine,
                'statut' => 'pending',
                'utilisateur'=>$user
            ]);
            
            if ($demande_en_cours) {
                $this->addFlash('warning', 'Une demande de retrait est déjà en attente de traitement pour cette tontine.');
                return $this->redirectToRoute('app_tontines_show', ['id' => $tontineId]);
            }
            
            // Créer une nouvelle demande de retrait
            $withdrawal = new Withdrawals();
            $withdrawal->setUtilisateur($user);
            $withdrawal->setAmount($amount);
            $withdrawal->setMethod($method);
            $withdrawal->setReason($reason);
            $withdrawal->setStatut('pending');
            $withdrawal->setRequestedAt(new \DateTimeImmutable());

            // Mettre à jour le solde de la tontine
            $tontine->setIsRetirer(false);

            

            // Enregistrer en base de données
            $em->persist($withdrawal);
            $em->flush();
//log
             $this->activityLogger->log(
                    $user,
                    'WITHDRAWAL_REQUEST',
                    'Transaction',
                    $withdrawal->getId(),
                    'demande de retrait de ' . $withdrawal->getAmount() . ' FCFA pour la tontine ' . $tontine->getTontineCode().' par '.$user->getUuid()
                );  
            $this->addFlash('success', 'Votre demande de retrait a été enregistrée avec succès.');
            return $this->redirectToRoute('app_tontines_show', ['id' => $tontineId]);
        } catch (\Exception $e) {
            $this->addFlash('error', 'Une erreur est survenue lors du traitement de votre demande de retrait.');
            return $this->redirectToRoute('app_tontines_show', ['id' => $tontineId]);
        //log
             $this->activityLogger->log(
                    $user,
                    'WITHDRAWAL_REQUEST',
                    'Transaction',
                    $withdrawal->getId(),
                    'demande de retrait de ' . $withdrawal->getAmount() . ' FCFA pour la tontine ' . $tontine->getTontineCode().' par '.$user->getUuid()
                ); 
        }
    }
}
