<?php

namespace App\Controller\Dashboard;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Service\CountryService;

#[Route('/dashboard')]
final class PagesController extends AbstractController
{
    private CountryService $countryService;

    public function __construct(CountryService $countryService)
    {
        $this->countryService = $countryService;
    }

    #[Route('/aide', name: 'app_aide')]
    public function aide(): Response
    {
        return $this->render('dashboard/pages/aide/aide.html.twig');
    }
    #[Route('/cgu', name: 'app_cgu')]
    public function cgu(): Response
    {
        return $this->render('dashboard/pages/legals/cgu.html.twig');
    }
    #[Route('/mentionlegal', name: 'app_mentions')]
    public function mentionlegal(): Response
    {
        return $this->render('dashboard/pages/legals/mentionlegal.html.twig');
    }
    #[Route('/tarif-et-frais', name: 'app_tarifs')]
    public function tarifetfrais(): Response
    {
        return $this->render('dashboard/pages/legals/tarifetfrais.html.twig');
    }
    #[Route('/faq', name: 'app_faq')]
    public function faq(): Response
    {
        return $this->render('dashboard/pages/legals/faq.html.twig');
    }
    #[Route('/contact', name: 'app_contact')]
    public function contact(): Response
    {
        return $this->render('dashboard/pages/legals/contact.html.twig');
    }
    #[Route('/active-compte', name: 'app_active_compte')]
    public function activeCompte(): Response
    {
        $user = $this->getUser();
        
        // Check if user is logged in
        if (!$user) {
            return $this->redirectToRoute('app_login');
        }
        
        return $this->render('dashboard/pages/compte/activecompte.html.twig', [
            'verification_status' => 'pending',
            'user' => $user,
            'user_has_basic_info' => $user && $user->getFirstname() && $user->getLastname() && $user->getPhone(),
            'nationalities' => $this->countryService->getCountries(),
            'user_data' => [
                'id' => $user->getId(),
                'firstName' => $user->getFirstname(),
                'lastName' => $user->getLastname(),
                'email' => $user->getEmail(),
                'phone' => $user->getPhone(),
                'nationality' => $user->getNationality()
            ]
        ]);
    }
    #[Route('/support', name: 'app_support')]
    public function support(): Response
    {
        // TODO: Implement support functionality
        return $this->render('dashboard/pages/support/support.html.twig');
    }
    
}