<?php

namespace App\Controller;

use App\Entity\Tontine;
use App\Entity\ActivityLog;
use App\Service\ActivityLogger;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[IsGranted('ROLE_USER')]
final class TontineController extends AbstractController
{
    public function __construct(
        private ActivityLogger $activityLogger
    ) {}
    #[Route('/tontine', name: 'app_tontine')]
    public function index(EntityManagerInterface $em): Response
    {
        //refuser si la tontine active de l'utilisateur est egal à 3
        $nrbtontineactive = $em->getRepository(Tontine::class)->count(['statut' => 'active', 'utilisateur' => $this->getUser()->getId()]);
        if ($nrbtontineactive >= 3) {
            //reponse message alert 
            $this->addFlash('error', 'Vous avez atteint le nombre maximum de tontines actives.');
            return $this->redirectToRoute('app_tontines_index');
        }
        return $this->render('tontine/index.html.twig', [
            'controller_name' => 'TontineController',
        ]);
    }
    #[Route('/api/tontine/create', name: 'app_tontine_create', methods: ['POST', 'GET'])]
    public function createTontine(
        Request $request,
        EntityManagerInterface $entityManager,
    ): JsonResponse {

        $this->denyAccessUnlessGranted('IS_AUTHENTICATED_FULLY');
        $user = $this->getUser();

        $data = json_decode($request->getContent(), true);

        if (!$data) {
            return $this->json([
                'success' => false,
                'message' => 'Données JSON invalides.'
            ], Response::HTTP_BAD_REQUEST);
        }

        // Champs obligatoires
        foreach (['name', 'amount', 'period', 'duration', 'startDate'] as $field) {
            if (empty($data[$field])) {
                return $this->json([
                    'success' => false,
                    'message' => "Le champ '$field' est obligatoire."
                ], Response::HTTP_BAD_REQUEST);
            }
        }

        // Validation montant
        if (!is_numeric($data['amount']) || $data['amount'] <= 0) {
            return $this->json([
                'success' => false,
                'message' => 'Montant invalide.'
            ], Response::HTTP_BAD_REQUEST);
        }

        // Fréquences autorisées
        $allowedPeriods = ['daily', 'weekly', 'monthly'];

        if (!in_array($data['period'], $allowedPeriods, true)) {
            return $this->json([
                'success' => false,
                'message' => 'La fréquence sélectionnée est invalide.'
            ], Response::HTTP_BAD_REQUEST);
        }

        // Date de début
        $startDate = \DateTime::createFromFormat('Y-m-d', $data['startDate']);
        if (!$startDate || $startDate < new \DateTime('today')) {
            return $this->json([
                'success' => false,
                'message' => 'Date de début invalide.'
            ], Response::HTTP_BAD_REQUEST);
        }

        // 🔢 Calcul du nombre total de versements
        $totalPoints = match ($data['period']) {
            'daily'   => $data['duration'] * 30,
            'weekly'  => $data['duration'] * 4,
            'monthly' => $data['duration'],
        };

        // 💰 Commission 10 %
        $commission = ($totalPoints * $data['amount']) * 0.10;

        try {
            $tontine = new Tontine();
            $tontine->setTontineCode($this->generateTontineCode($entityManager));
            $tontine->setAmountPerPoint((float) $data['amount']);
            $tontine->setTotalPoints($totalPoints);
            $tontine->setFrequency($data['period']);
            $tontine->setStartDate($startDate);
            $tontine->setStatut('active');
            $tontine->setName($data['name']);
            $tontine->setCreatedAt(new \DateTimeImmutable());
            $tontine->setUtilisateur($user);

            $entityManager->persist($tontine);
            $entityManager->flush();
//log   
            $this->activityLogger->log(
                $user,
                'TONTINE_CREATED',
                'Tontine',
                $tontine->getId(),
                'Création d’une nouvelle tontine'
            );

            return $this->json([
                'success' => true,
                'tontineId' => $tontine->getId(),
                'totalPoints' => $totalPoints,
                'commission' => $commission
            ], Response::HTTP_CREATED);
        } catch (\Throwable $e) {
            return $this->json([
                'success' => false,
                'message' => 'Erreur interne.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    private function generateTontineCode(EntityManagerInterface $em): int
    {
        // Générer un code des tontines unique
        do {
            $code = random_int(10000, 99999);
            $exists = $em->getRepository(Tontine::class)
                ->findOneBy(['tontineCode' => $code]);
        } while ($exists);

        return $code;
    }
}
