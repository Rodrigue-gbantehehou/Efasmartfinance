<?php

namespace App\Controller\Admin;

use App\Repository\UserRepository;
use App\Repository\TontineRepository;
use App\Repository\TransactionRepository;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/admin/reports')]
class ReportAdminController extends AbstractController
{
    #[Route('', name: 'admin_reports')]
    public function index(
        TransactionRepository $transactionRepository,
        UserRepository $userRepository,
        TontineRepository $tontineRepository
    ): Response {
        // Récupérer les statistiques pour le tableau de bord
        $stats = [
            'total_users' => $userRepository->count([]),
            'active_tontines' => $tontineRepository->count(['statut' => 'active']),
            'completed_tontines' => $tontineRepository->count(['statut' => 'completed']),
            'total_transactions' => $transactionRepository->count([]),
            'total_volume' => $transactionRepository->getTotalVolume(),
        ];

        return $this->render('admin/reports/index.html.twig', [
            'stats' => $stats,
        ]);
    }

    #[Route('/transactions', name: 'admin_reports_transactions')]
    public function transactions(TransactionRepository $transactionRepository): Response
    {
        $transactions = $transactionRepository->findBy([], ['createdAt' => 'DESC']);
        
        return $this->render('admin/reports/transactions.html.twig', [
            'transactions' => $transactions,
        ]);
    }

    #[Route('/users', name: 'admin_reports_users')]
    public function users(UserRepository $userRepository): Response
    {
        $users = $userRepository->findBy([], ['createdAt' => 'DESC']);
        
        return $this->render('admin/reports/users.html.twig', [
            'users' => $users,
        ]);
    }

    #[Route('/create', name: 'admin_reports_create')]
    public function create(): Response
    {
        // For now, redirect to the reports index
        // In a real implementation, this would show a form to configure and generate reports
        $this->addFlash('info', 'La génération de rapports sera bientôt disponible.');
        return $this->redirectToRoute('admin_reports');
    }
}
