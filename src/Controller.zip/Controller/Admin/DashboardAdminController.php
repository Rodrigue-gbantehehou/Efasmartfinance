<?php
// src/Controller/DashboardAdmin/DashboardAdminController.php

namespace App\Controller\Admin;

use App\Entity\ActivityLog;
use App\Repository\UserRepository;
use App\Repository\TontineRepository;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\TransactionRepository;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/admin')]
//#[IsGranted('ROLE_ADMIN')]
class DashboardAdminController extends AbstractController
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private UserRepository $userRepository,
        private TontineRepository $tontineRepository,
        private TransactionRepository $transactionRepository
    ) {
    }
    
    #[Route('/', name: 'admin_dashboard')]
    public function dashboard(): Response {
        // Get statistics
        $stats = [
            'total_users' => $this->userRepository->count([]),
            'user_growth' => $this->calculateUserGrowth($this->userRepository),
            'active_tontines' => $this->tontineRepository->countActive(),
            'completed_tontines' => $this->tontineRepository->countCompleted(),
            'total_transactions' => $this->transactionRepository->count([]),
            'today_transactions' => $this->transactionRepository->countTodayTransactions(),
            'total_revenue' => $this->transactionRepository->getTotalRevenue(),
            'revenue_growth' => $this->calculateRevenueGrowth($this->transactionRepository),
        ];
        
        // Get recent activities
        $recentActivities = $this->getRecentActivities();
        
        return $this->render('admin/dashboard.html.twig', [
            'stats' => $stats,
            'recent_activities' => $recentActivities,
            'user_count' => $stats['total_users'],
            'tontine_count' => $stats['active_tontines'] + $stats['completed_tontines'],
            'transaction_count' => $stats['total_transactions'],
            'support_ticket_count' => 0, // Implement this based on your support system
            'online_users' => $this->getOnlineUsersCount(),
        ]);
    }
    
    #[Route('/users', name: 'admin_users')]
    public function users(UserRepository $userRepository): Response
    {
        $users = $userRepository->findAll();
        
        return $this->render('admin/pages/users/index.html.twig', [
            'users' => $users
        ]);
    }
    
    #[Route('/users/create', name: 'admin_users_create')]
    public function createUser(Request $request): Response
    {
        // TODO: Implémenter la logique de création d'utilisateur
        // Cette méthode devra gérer l'affichage du formulaire et le traitement de la soumission
        
        return $this->render('admin/pages/users/create.html.twig', [
            // Passer les données nécessaires au formulaire
        ]);
    }
    
    #[Route('/users/{id}/edit', name: 'admin_users_edit')]
    public function editUser(int $id, UserRepository $userRepository): Response
    {
        $user = $userRepository->find($id);
        
        if (!$user) {
            throw $this->createNotFoundException('Utilisateur non trouvé');
        }
        
        return $this->render('admin/pages/users/edit.html.twig', [
            'user' => $user
        ]);
    }
    
    #[Route('/tontines', name: 'admin_tontines')]
    public function tontines(TontineRepository $tontineRepository): Response
    {
        $tontines = $tontineRepository->findAll();
        
        return $this->render('admin/pages/tontines/index.html.twig', [
            'tontines' => $tontines,
            'tontine_count' => count($tontines),
        ]);
    }
    
    #[Route('/transactions', name: 'admin_transactions')]
    public function transactions(TransactionRepository $transactionRepository): Response
    {
        $transactions = $transactionRepository->findAll();
        
        return $this->render('admin/pages/transactions/index.html.twig', [
            'transactions' => $transactions,
            'transaction_count' => count($transactions),
        ]);
    }
    
    #[Route('/reports', name: 'admin_reports')]
    public function reports(): Response
    {
        return $this->render('admin/pages/reports/index.html.twig');
    }
    
    #[Route('/support', name: 'admin_support')]
    public function support(): Response
    {
        return $this->render('admin/pages/support/index.html.twig');
    }
    
    #[Route('/audit/logs', name: 'admin_audit_logs')]
    public function auditLogs(Request $request): Response
    {
        $logs = $this->entityManager->getRepository(ActivityLog::class)
            ->createQueryBuilder('a')
            ->leftJoin('a.utilisateur', 'u')
            ->addSelect('u')
            ->orderBy('a.createdAt', 'DESC')
            ->getQuery()
            ->getResult();
            
        // Gestion de l'export CSV
        if ($request->query->get('export') === 'csv') {
            return $this->exportLogsToCsv($logs);
        }
            
        return $this->render('admin/pages/audit/logs.html.twig', [
            'logs' => $logs,
        ]);
    }
    
    private function exportLogsToCsv(array $logs): Response
    {
        $filename = 'logs-audit-' . date('Y-m-d') . '.csv';
        
        $response = new Response();
        $response->headers->set('Content-Type', 'text/csv');
        $response->headers->set('Content-Disposition', 'attachment; filename="' . $filename . '"');
        
        $handle = fopen('php://output', 'w+');
        
        // En-têtes CSV
        fputcsv($handle, [
            'Date',
            'Utilisateur',
            'Email',
            'Action',
            'Détails',
            'Adresse IP'
        ], ';');
        
        // Données
        foreach ($logs as $log) {
            fputcsv($handle, [
                $log->getCreatedAt() ? $log->getCreatedAt()->format('d/m/Y H:i:s') : '',
                $log->getUtilisateur() ? $log->getUtilisateur()->getFirstName() . ' ' . $log->getUtilisateur()->getLastName() : 'Système',
                $log->getUtilisateur() ? $log->getUtilisateur()->getEmail() : 'Système',
                $log->getActions(),
                $log->getDescription(),
                $log->getIpAdress()
            ], ';');
        }
        
        fclose($handle);
        
        return $response;
    }
    
    #[Route('/settings', name: 'admin_settings')]
    public function settings(): Response
    {
        return $this->render('admin/pages/settings/index.html.twig');
    }
    
    #[Route('/backup', name: 'admin_backup')]
    public function backup(): Response
    {
        return $this->render('admin/pages/backup/index.html.twig');
    }
    
    #[Route('/profile', name: 'admin_profile')]
    public function profile(): Response
    {
        return $this->render('admin/pages/profile/index.html.twig');
    }
    
    private function calculateUserGrowth(UserRepository $userRepository): float
    {
        $currentMonthCount = $userRepository->countThisMonth();
        $lastMonthCount = $userRepository->countLastMonth();
        
        if ($lastMonthCount === 0) {
            return $currentMonthCount > 0 ? 100.0 : 0.0;
        }
        
        return round((($currentMonthCount - $lastMonthCount) / $lastMonthCount) * 100, 1);
    }
    
    private function calculateRevenueGrowth(TransactionRepository $transactionRepository): float
    {
        $currentMonthRevenue = $transactionRepository->getCurrentMonthRevenue();
        $lastMonthRevenue = $transactionRepository->getLastMonthRevenue();
        
        if ($lastMonthRevenue === 0) {
            return $currentMonthRevenue > 0 ? 100.0 : 0.0;
        }
       if ($lastMonthRevenue == 0) {
        return $currentMonthRevenue > 0 ? -100.0 : 0.0;
       } else {
        return round((($currentMonthRevenue - $lastMonthRevenue) / $lastMonthRevenue) * 100, 1);
       }
    }
    
    private function getRecentActivities(): array
    {
        // This should come from your activity log system

        $recentActivities = $this->entityManager->getRepository(ActivityLog::class)->findBy([], ['createdAt' => 'DESC'], 5);
        
        return $recentActivities;
    }
    
    private function getOnlineUsersCount(): int
    {
        // Implement logic to count online users
        // This could be based on session activity
        return rand(15, 45); // Placeholder
    }
}